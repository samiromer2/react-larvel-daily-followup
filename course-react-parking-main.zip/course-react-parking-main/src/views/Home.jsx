function Home() {
  return <div>This is home view</div>
}

export default Home
